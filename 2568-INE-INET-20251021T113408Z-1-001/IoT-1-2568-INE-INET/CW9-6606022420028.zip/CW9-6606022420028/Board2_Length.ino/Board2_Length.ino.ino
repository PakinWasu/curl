#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6wTFjfDaN"
#define BLYNK_TEMPLATE_NAME "Ultrasonic"
#define BLYNK_AUTH_TOKEN "SBw8QUSa6J0I7dyi_63NXw4cTbXOjXeX"

#include <ESP8266WiFi.h>
#include <BlynkSimpleEsp8266.h>

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define SCREEN_WIDTH 128  // pixel ความกว้าง
#define SCREEN_HEIGHT 64  // pixel ความสูง
#define OLED_RESET -1  //ขา reset เป็น -1 ถ้าใช้ร่วมกับขา Arduino reset
Adafruit_SSD1306 OLED(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
unsigned long previousMillis = 0;
const long interval = 10000;
char ssid[] = "Iot";
char pass[] = "00000000";
const int trigPin = D6;
const int echoPin = D7;
float lengthV = 0;
float length_of_box = 0;

BlynkTimer timer;

float readDistanceCM() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duration = pulseIn(echoPin, HIGH, 30000);
  if (duration == 0) return NAN;
  return duration * 0.034 / 2.0;
}

void sendLength() {
  lengthV = readDistanceCM();
  length_of_box = 50 - lengthV;
  if (!isnan(lengthV)) {

    // Blynk.virtualWrite(V1, length_of_box);
    Serial.print("Length : ");
    Serial.print(lengthV);
    Serial.print("Length of box : ");
    Serial.println(length_of_box);
  } else {
    Serial.println("Length read failed");
  }
}

void setup() {


  Serial.begin(9600);
  if (!OLED.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {  // สั่งให้จอ OLED เริ่มทำงานที่ Address 0x3C
    Serial.println("SSD1306 allocation failed");
  } else {
    Serial.println("ArdinoAll OLED Start Work !!!");
  }

  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
  timer.setInterval(1000L, sendLength);
}

void loop() {
  
  Blynk.run();
  timer.run();
  OLED.clearDisplay();              // ลบภาพในหน้าจอทั้งหมด
  OLED.setTextColor(WHITE, BLACK); 
  OLED.setCursor(0, 0);  // กำหนดตำแหน่ง x,y ที่จะแสดงผล
  OLED.setTextSize(1);
  OLED.print("Length Set : ");
  OLED.println(String(lengthV, 2));
  OLED.setCursor(0, 15);  // กำหนดตำแหน่ง x,y ที่จะแสดงผล
  OLED.setTextSize(1);
  OLED.print("Length of box : ");
  OLED.println(String(length_of_box, 2));
  
  OLED.display();
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    Blynk.virtualWrite(V1, length_of_box);
  }
  // delay(10000);
}
