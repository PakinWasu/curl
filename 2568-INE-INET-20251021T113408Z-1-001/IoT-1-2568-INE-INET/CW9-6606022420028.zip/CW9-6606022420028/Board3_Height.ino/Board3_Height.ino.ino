#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6wTFjfDaN"
#define BLYNK_TEMPLATE_NAME "Ultrasonic"
#define BLYNK_AUTH_TOKEN "SBw8QUSa6J0I7dyi_63NXw4cTbXOjXeX"

#include <ESP8266WiFi.h>
#include <BlynkSimpleEsp8266.h>

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#define SCREEN_WIDTH 128  // pixel ความกว้าง
#define SCREEN_HEIGHT 64  // pixel ความสูง
#define OLED_RESET -1     //ขา reset เป็น -1 ถ้าใช้ร่วมกับขา Arduino reset
Adafruit_SSD1306 OLED(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
unsigned long previousMillis = 0;
const long interval = 10000;
char ssid[] = "Iot";
char pass[] = "00000000";
const int trigPin = D6;
const int echoPin = D7;
float heightV = 0;
float heighth_of_box = 0;

BlynkTimer timer;

float readDistanceCM() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duration = pulseIn(echoPin, HIGH, 30000);
  if (duration == 0) return NAN;
  return duration * 0.034 / 2.0;
}

void sendHeight() {
  heightV = readDistanceCM();
  heighth_of_box = 33.5 - heightV;
  if (!isnan(heightV)) {
    // Blynk.virtualWrite(V2, heightV);
    Serial.print("Height: ");
    Serial.println(heightV);
    Serial.print("Height of Box: ");
    Serial.println(heighth_of_box);
  } else {
    Serial.println("Height read failed");
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  if (!OLED.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {  // สั่งให้จอ OLED เริ่มทำงานที่ Address 0x3C
    Serial.println("SSD1306 allocation failed");
  } else {
    Serial.println("ArdinoAll OLED Start Work !!!");
  }
  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
  timer.setInterval(1000L, sendHeight);
}

void loop() {
  Blynk.run();
  timer.run();
  OLED.clearDisplay();  // ลบภาพในหน้าจอทั้งหมด
  OLED.setTextColor(WHITE, BLACK);
  OLED.setCursor(0, 0);  // กำหนดตำแหน่ง x,y ที่จะแสดงผล
  OLED.setTextSize(1);
  OLED.print("heighth Set : ");
  OLED.println(String(heightV, 2));
  OLED.setCursor(0, 15);  // กำหนดตำแหน่ง x,y ที่จะแสดงผล
  OLED.setTextSize(1);
  OLED.print("heighth of box : ");
  OLED.println(String(heighth_of_box, 2));

  OLED.display();
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    Blynk.virtualWrite(V2, heighth_of_box);
  }
  // delay(10000);
}
