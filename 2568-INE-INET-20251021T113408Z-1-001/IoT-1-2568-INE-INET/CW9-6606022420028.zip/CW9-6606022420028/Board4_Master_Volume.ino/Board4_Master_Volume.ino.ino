#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6wTFjfDaN"
#define BLYNK_TEMPLATE_NAME "Ultrasonic"
#define BLYNK_AUTH_TOKEN "SBw8QUSa6J0I7dyi_63NXw4cTbXOjXeX"
#include <ESP8266WiFi.h>
#include <BlynkSimpleEsp8266.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128  // pixel ความกว้าง
#define SCREEN_HEIGHT 64  // pixel ความสูง

#define OLED_RESET -1  //ขา reset เป็น -1 ถ้าใช้ร่วมกับขา Arduino reset
Adafruit_SSD1306 OLED(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

char ssid[] = "Iot";
char pass[] = "00000000";

float widthVal = 0, lengthVal = 0, heightVal = 0;
float volume = 0;
BlynkTimer timer;

BLYNK_WRITE(V0) {
  widthVal = param.asFloat();
}
BLYNK_WRITE(V1) {
  lengthVal = param.asFloat();
}
BLYNK_WRITE(V2) {
  heightVal = param.asFloat();
}

void sendVal() {
  volume = widthVal * lengthVal * heightVal;
  Blynk.virtualWrite(V3, volume);
  Serial.printf("Calculate Volume: %.2f (W=%.2f, L=%.2f, H=%.2f)\n", volume, widthVal, lengthVal, heightVal);
}

void setup() {
  Serial.begin(9600);
  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
  timer.setInterval(10000L, sendVal);
  Blynk.syncVirtual(V0, V1, V2);
  if (!OLED.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {  // สั่งให้จอ OLED เริ่มทำงานที่ Address 0x3C
    Serial.println("SSD1306 allocation failed");
  } else {
    Serial.println("ArdinoAll OLED Start Work !!!");
  }
}

void loop() {
  Blynk.run();
  timer.run();
  Blynk.syncVirtual(V0, V1, V2);
  OLED.clearDisplay();              // ลบภาพในหน้าจอทั้งหมด
  OLED.setTextColor(WHITE, BLACK);  //กำหนดข้อความสีขาว ฉากหลังสีดำ

  OLED.setCursor(0, 0);  // กำหนดตำแหน่ง x,y ที่จะแสดงผล
  OLED.setTextSize(1);
  OLED.print("Volume = ");
  OLED.println(String(volume, 2));  // แสดงผลข้อความ ALL
  OLED.setCursor(0, 15);
  OLED.setTextSize(1);
  OLED.print("Width = ");
  OLED.println(String(widthVal, 2));
  OLED.setCursor(0, 30);
  OLED.setTextSize(1);
  OLED.print("Length = ");
  OLED.println(String(lengthVal, 2));
  OLED.setCursor(0, 45);
  OLED.setTextSize(1);
  OLED.print("Highth = ");
  OLED.println(String(heightVal, 2));
  OLED.display();
  delay(10000);

}
